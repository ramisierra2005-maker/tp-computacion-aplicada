mkdir /home/matias/.papelera_estudiante
su matias
nano /home/matias/.bashrc 
su - matias
nano /home/matias/.bashrc 
su - matias
clear
nano /home/matias/.bashrc 
su - matias
chown matias /home/matias/.papelera_estudiante/
su - matias
find -type d -name crontab
find / -type d -name crontab
find / -type d -name *cron*
cd /var/spool/cron/crontabs
ls
cd matias
rm matias
ls
cd ..
cd..
userdel -rf matias
ls /home/matias
clear
cd
apt install gcc
sytemctl status rsyslog
systemctl status rsyslog
clear
nano zombies.c
gcc -o zombies.c zombies
gcc -o zombies zombies.c
./zombies
find / -type f -name *servidor*
top
clear
ps -ef
kill -47151
kill -9 47151
clear
find / -type f -name *servidor*
./zombies
ps -ef
kill -9 47170
clear
nano zombies.c
gcc -o zombies zombies.c
./zombies
ps aux
clear
ps -ef
kill -9 47196
clear
rm zombies
nano zombies.c 
gcc -o romero zombies.c
./romero 
ps aux
clear
cp romero archivos_tp/
rm romero 
nano archivos_tp/romero 
nano zombies.c 
gcc -o romero zombies.c
./romero
ps aux
clear
ps -ef
kill -9 47268
kill -9 47223
clear
mv romero archivos_tp/
ls
rm zombies.c 
cd archivos_tp
apt purge --autoremove nano
naon /etc/apt/sources.list
vi /etc/apt/sources.list
apt install nano
apt install vim
clear
vi /etc/apt/sources.list
apt install nano
apt install lynx
apt purge --autoremove nano
clar
clear
apt install nano
apt update
apt install nano
vi /etc/apt/sources.list
apt update
clear
apt install nano
clear
cd ..
cat /etc/network/interfaces
exit
ip a
find / -type d -name *videos
clear
cd /var/www
apt purge --autoremove openssh-server
clear
rm -rf /etc/ssh
rm -rf /etc/.ssh /home/*/.ssh
dpkg -l | grep openssh
apt clean
dpkg -l | grep openssh
clear
apt purge -y openssh-client openssh-sftp-server
dpkg -purge $(dpkg -l | grep "openssh" | awk "{print $2}")
dpkg --purge $(dpkg -l | grep "openssh" | awk "{print $2}")
clear
dpkg -l | grep openssh
apt purge openssh-client
dpkg -l | grep openssh
clear
find /etc/ -type d -name *ssh*
su - matias
cat /etc/groups
cat /etc/group
clear
vi /bin/stamp.sh
chmod +x /bin/stamp.sh 
stamp
stamp.sh
vi /bin/stamp.sh
stamp.sh
vi /bin/stamp.sh
stamp.sh
cat /var/.stamp 
cat /var/.stamp 
reboot now
cat /var/.stamp 
nano /bin/stamp.sh 
vi /bin/stamp.sh 
stamp.sh
cat /var/.stamp 
mv /bin/stamp.sh /etc/.stamp.sh
clear
vi /etc/rc.local
ls /etc/rc.local
vi /etc/profile
chmod 777 /var/.stamp 
chmod 777 /etc/.stamp.sh 
reboot now
cat /var/.stamp 
date
shutdown
ls
cd archivos_tp/
ls
cd ..
ls -la
ls
cd archivos_tp/
ls
nano romero
vi romero
clear
ls -l romero
ps aux
clear
nano index.php
cat db.sql
clear
rm romero
ls
cat /etc/passwd
clear
lsblk
clear
systemctl status mariadb
systemctl status apache2
find / -type f -name os-release
find / -type f -name *.ser*
cat /opt/.servidorweb 
clear
shutdown now
clear
ls
cd archivos_tp/
ls
nano db.sql
vi db.sql
shutdown now
clear
cd archivos_tp/
vi db.sql 
vi archivos_tp/
cd archivos_tp/
ls
vi db.sql 
clear
vi db.sql 
clear
lsmod | grep
lsmod | grep vbox
VBoxControl --version
modprobe vboxsf
lsmod | grep vboxsf
apt install -y virtualbox-guest-utils virtualbox-gues-dkms
apt install -y virtualbox-guest-utils virtualbox-guest-dkms
vi db.sql 
vi db.sql 
vi db.sql 
vi db.sql 
ip a
cd /mnt/
ls
shutdown -r now
ls /mnt/
ls
cd /media/
ls
cd ..
cd /media/
ls
ls -l
cd cdrom0
ls
cd ..
cd ..
ls /media
shutdown -r now
cd /media/
ls
ls
cd ..
shutdown -r now
ls /mnt/
ls /media/
ls
clear
wget
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
wget http://192.168.0.6:8000/db2.sql -O /root/archivos_tp/db2.sql
ls
cd archivos_tp/
ls
mv db.sql db.original.sql
mv db2.sql db.sql
mariadb < db.sql 
vi index.php
vi index.php
cd /usr/bin/.videos/
ls
rm airbag.mp4 bcnr.mp4 boa.mp4 metallica.mp4 nirvana.mp4 omar_courtz.mp4 remera.mp4 rod_stewart.mp4 sabrina_carpenter.mp4 spinetta.mp4 tarea_fina.mp4 taylor_swift.mp4 
ls
cat /root/archivos_tp/db.sql 
clear
wget -r-nd -A.mp4 http://192.168.0.6:8000/
wget -r -nd -A.mp4 http://192.168.0.6:8000/
ls
ls -l
clear
cd
ls
cd archivos_tp/
ls
rm db.original.sql 
clear
shutdown now
hostname
loadkeys us
localect status
localtetcl status
dpkg-reconfigure keyboard-configuration
clear
cat /etc/default/keyboard
loadkeys us
reboot
cat /etc/network/interfaces
vi /etc/network/interfaces
ifup enp0s1
ping -c 3 deb.debian.org
cat /etc/os-release
cat /etc/apt/sources.list
vi /etc/apt/sources.list
clear
apt update
vi /etc/apt/sources.list
clear
apt update
apt full-upgrade
reboot
exit
cat /etc7os-release
cat /etc/os-release
dpkg -l openssh-server
apt intsall opnessh-server
apt install opnessh-server
apt install openssh-server
systemctl status ssh
ls -la /root/archivos_tp
mkdir -p /root/.ssh
cp /root/archivos_tp/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
greep -i PermitRootLogin /etc/ssh/sshd_config
grep -i PermitRootLogin /etc/ssh/sshd_config
sshd -T | grep permitrootlogin
ssh -i /root/archivos_tp/clave_privada.txt -o identitiesOnly=yes root@local
chmod 600 /root/archivos_tp/clave_privada.txt
ssh -i /root/archivos_tp/clave_privada.txt -o identitiesOnly=yes root@local
ssh -i /root/archivos_tp/clave_privada.txt -o identitiesOnly=yes root@localhost
apt install rsyslog
systemctl status rsyslog
find /root -name '*servidorweb*' -print
find -name '*servidorweb*' 2>/dev/null
find / -iname '*servidorweb*' 2>/dev/null
cat /opt/.servidorweb
apt install apache2
systemctl status apache2
apt install php libapache2-mod-php php-msyql
apt update
apt search phph8.2-msyql
cat /etc/apt/sources.list
apt-cache policy php php-mysql phph8.2-mysql
apt-cache policy php php-mysql php8.2-mysql
apt search php8.2-msyql
apt install php libapache2-mod-php php-mysql
php -v
cp /root/archivos_tp/index.php /var/www/html/
curl http://localhost/index.php
uptime
apt install mariadb-server
systemctl status mariqdb
systemctl status mariadb
cat /root/archivos_tp/db.sql
mariadb -e "CREATE DATABASE IF NOT EXISTS ca_viernes;"
mariadb < /root/archivos_tp/db.sql
mariadb -e "SELECT COUNT(*) FROM ca_viernes.videos;"
cat /root/archivos_tp/index.php
head -n 35 /root/archivos_tp/index.php
grep -nE 'mysqli|PD0|ca_viernes|computacion' /root/archivos_tp/index.php
mariadb -u computacion -p ca_viernes
php -l /var/www/html/index.php
apt install curl
curl -I http://localhost/index.php
curl -s http://localhost/index.php | head -n 20
curl -s http://localhost/index.php | grep -iE 'error|SQLSTATE|playlist|video'
ip a
ip route
cat /etc/network/interfaces
nano /etc/network/interfaces
apt install nano
nano /etc/network/interfaces
systemctl restart networking
ip a
nano /etc/sysctl.conf
sysctl -p
ip -6 addr
ping -c 4 8.8.8.8
ip route
ip route add default via 192.168.64.1 dev enp0s1
ping -c 4 8.8.8.8
cat /etc/network/interfaces
reboot
ip a route
ip route
cat /etc/network/interfaces
ls -la /etc/network/interfaces.d/
ifquery --state enp0s1
systemctl status networking --no-pager
yfquery enp0s1
ifquery enp0s1
nano /etc/network/interfaces
systemctl restart networking 
ip route
ping -c 4 192.168.64.1
ip route add default via 192.168.64.1 dev enp0s1
ip route
reboot
ip route
ifquery --state enp0s1
ifquery enp0s1
journalctl -u networking -b --no-pager -n 40
systemctl status networking --no-pager -l
ifup -v enp0s1
ifdown -v enp0s1
ifup -v enp0s1
ip route
grep -n gateway /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking
ip route
ping -c 4 8.8.8.8
ping -c 4 google.com
apt update
apt ful-upgrade
apt full-upgrade
reboot
echo $SSH_CONNECTION
exit
dpkg -l openssh-server
systemctl status ssh --no-pager
ls -la /root/archivos_tp
ls -la /root/.shh
ls -la /root/.ssh
ssh-keygen -lf /root/.ssh/authorized_keys
ssh-keygemn -lf /root/archivos_tp/clave_publica.pub
ssh-keygen -lf /root/archivos_tp/clave_publica.pub
sshd -T | grep -E '^(permitrootlogin|pubkeyauthentication|authorizedkeysfile)'
sshd -T | grep -E '^(permitrootlogin|passwordauthentication|pubkeyauthentication)'
ssh -i /root/archivos_tp/clave_privada.txt -o identitiesOnly=yes root@17.0.0.1
ssh -i /root/archivos_tp/clave_privada.txt -0 identitiesOnly=yes root@17.0.0.1
ssh -i /root/archivos_tp/clave_privada.txt -0 identitiesOnly=yes root@17.0.0.1
ssh -i /root/archivos_tp/clave_privada.txt -o identitiesOnly=yes root@17.0.0.1
ssh -v -o ConnectTimeout=5 -i /root/archivos_tp/clave_privada.txt root@127.0.0.1
dpkg -l rsysl0g
dpkg -l rsyslog
systemctl is-active rsyslog
find / name "*servidorweb*" 2>/dev/null
systemctl is-active mariadb
mariadb -e "SHOW DATABASES;"
mariadb -e "SHOW TABLES FROM ca_viernes:"
maria db ca_viernes
mariadb ca_viernes
systemctl is-active apache2
php -v
ls -l /var/www/html/
curl -I https://localhost/index.php
curl -I https://127.0.0.1/index.php
curl -v --max-time 10 http://127.0.0.1/index.php
curl -I http://127.0.0.1/
grep -i DirectoryIndex /etc/apache2/mods-enabled/dir.conf
nano /etc/apache2/mods-enabled/dir.conf
systemctl restart apache2
clear
lsblk
poweroff
lsblk
fdisk /dev/sdb
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdb1 /www_dir
mount /dev/sdb2 /backup_dir
blkid /dev/sdb1 /dev/sdb2
nano /etc/fstab
mount -a
df -h /www_dir /backuo_dir
df -h /www_dir /backup_dir
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.pnp /www_dir/
cp /var/www/html/logo.png /www_dir/
ls -la /var/www/html/
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restart apache2
mkdir /proc/particiones
adduser estudiante
ls -la
clear
ls -la /www_dir/
grep DocumentoRoot/etc/apache2/sites-available/000-default.conf
clear
grep DocumentoRoot /etc/apache2/sites-available/000-default.conf
clear
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
grep -A 4 'Directory /www_dir/' /etc/apache2/apache.conf
grep -A 4 'Directory /www_dir/' 
 /etc/apache2/apache.conf
grep -a 4 '<Directory /www_dir/>' /etc/apache2/apache.conf
grep -a 4 '<Directory /www_dir/>' /etc/apache2/apache2.conf
nano /etc/apache2/apache2.conf
clear
ls -la /www_dir/
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/apache2.conf
clear
systemctl status apache 1
systemctl status apache 2
clear
systemctl status apache2
clear
systemctl status apache2
clear
cat /etc/fstab
grep -nE 'www_dir|nackup_dir' /etc/fstab
grep -nE 'www_dir|backup_dir' /etc/fstab
blkid /dev/sdb1
nano /etc/fstab
cat /etc/fstab
df -h /www_dir
clear
df -h /www_dir
reboot
df -h /www_dir
blkid /dev/sdb2
nano /etc/fstab
reboot
