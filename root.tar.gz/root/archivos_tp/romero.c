#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0); /* salida sin buffer */

    printf("romero: soy el proceso padre, PID %d\n", getpid());

    for (int i = 0; i < 5; i++) {
        pid_t pid = fork(); /* crea un proceso hijo */

        if (pid == 0) {
            _exit(0); /* el hijo termina enseguida */
        }

        printf(" hijo creado: PID %d\n", pid);
    }

    while (1) {
        sleep(60); /* el padre nunca llama a wait() */
    }
}
