#!/bin/bash

# Mostrar ayuda
if [ "$1" = "-help" ]; then
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi

# Validar argumentos
if [ "$#" -ne 2 ]; then
    echo "Error: Debes indicar origen y destino."
    echo "Usa -help para obtener ayuda."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar que el origen exista
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen no existe."
    exit 1
fi

# Validar que el destino exista
if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino no existe."
    exit 1
fi

# Validar que el destino sea la particion de backup
if [ "$DESTINO" != "/backup_dir" ]; then
    echo "Error: El destino debe ser /backup_dir."
    exit 1
fi

# Verificar que la particion de backup este montada
if ! mountpoint -q -- /backup_dir; then
    echo "Error: La particion de backup no esta montada."
    exit 1
fi

# Generar nombre con fecha ANSI
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crear el backup comprimido
tar -czf "$DESTINO/$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"

# Comprobar el resultado
if [ "$?" -eq 0 ]; then
    echo "Backup realizado correctamente."
    echo "Archivo generado: $DESTINO/$ARCHIVO"
else
    echo "Error al realizar el backup."
    exit 1
fi
